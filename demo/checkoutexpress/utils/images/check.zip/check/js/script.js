﻿var demoApp = angular.module('demoApp', ['ngRoute']);

var baseURL = 'http://localhost:1337';

demoApp.config(function ($routeProvider, $locationProvider) {
    $locationProvider.html5Mode(true);
    $routeProvider
    .when('/demo', {
        templateUrl : '/check/demo.html',
        controller  : 'ccController'
    }).when('/checkout', {
        templateUrl : '/check/checkout.html',
        controller  : 'ccController',
        activetab: 'checkout'
    })    
});

demoApp.controller('ccController', function ($rootScope, $scope, $routeParams, $location, $http, $window) {
    console.log('in controller1    ')
    $scope.citrusMerchantTxnId = (new Date()).getTime();
    console.log('  pay mode ' + JSON.stringify($location.hash()))
    var MODE = 'card';
    
    console.log('  citrusMerchantTxnId  ' + $scope.citrusMerchantTxnId)
    var merchantAccessKey = '';
    
    //  makePaymentCC()
    function makePaymentCC(MODE) {
        console.log('mode    :   '+MODE)
        var postData = {};
       
        var email = document.getElementById("citrusEmail").value;
        var citrusMobile = document.getElementById("citrusMobile").value;
        var amount = document.getElementById("citrusAmount").value;
        var citrusSignature = document.getElementById("citrusSignature");
        var firstName = document.getElementById("citrusFirstName").value;
        
        if (firstName != '' && firstName != null && typeof firstName != 'undefined') {
            postData['firstName'] = firstName;
        }
        
        postData['email'] = email;
        postData['mobile'] = citrusMobile;
        postData['txn_id'] = $scope.citrusMerchantTxnId;
        postData['amount'] = amount;
        
        console.log('in controller1    ' + JSON.stringify(postData))
        $rootScope.checkoutDetails = null;
        
        $http.post(baseURL + "/generateSignature/", postData)
                       .success(function (data) {
            
            console.log('data   : ' + JSON.stringify(data))
            
            citrusMerchantTxnId.value = data.TransId;
            citrusSignature.value = data.TransSignature;
            merchantAccessKey.value = data.AccessKey;
            var merchantVanityURL = data.VanityURL;
            CitrusPay.Merchant.Config = {
                Merchant: {
                    accessKey: data.AccessKey,
                    vanityUrl: data.VanityURL
                }
            };
            if (MODE == 'card') {
                makePayment("card");
            }
            else { 
                makePayment("netbanking")
            }
        })
                    .error(function (data) { alert('error in transaction') });
    }
    
    $scope.checkforNULL = function () {
        console.log('check for null   :')
        var payMode = $location.hash()
        
        if (payMode == 'debit') {
            document.getElementById("citrusCardType").value = 'debit';
            document.getElementById("citrusNumber").value = document.getElementById("citrusNumber1").value;
            document.getElementById("citrusCardHolder").value = document.getElementById("citrusCardHolder1").value;
            document.getElementById("citrusCvv").value = document.getElementById("citrusCvv1").value;
            document.getElementById("citrusExpiry").value = document.getElementById("citrusExpiry1").value;
        }
        else {
            document.getElementById("citrusCardType").value = 'credit';
            document.getElementById("citrusNumber").value = document.getElementById("citrusNumber").value;
            document.getElementById("citrusCardHolder").value = document.getElementById("citrusCardHolder").value;
            document.getElementById("citrusCvv").value = document.getElementById("citrusCvv").value;
            document.getElementById("citrusExpiry").value = document.getElementById("citrusExpiry").value;
        }
                
        var cardNumber = document.getElementById("citrusNumber");
        var cardExpiry = document.getElementById("citrusExpiry");
        var cardCvv = document.getElementById("citrusCvv");
        var cardHolder = document.getElementById("citrusCardHolder");

        var email = document.getElementById("citrusEmail").value;
        var citrusMobile = document.getElementById("citrusMobile").value;
        console.log('  value 1  ' + JSON.stringify($location.search()))
        
        if (email == null && email == "" && typeof email == 'undefined') {
            alert('Please Enter Email ID . . .');
        }
        if (citrusMobile == null && citrusMobile == "" && typeof citrusMobile == 'undefined') {
            alert('Please Enter Mobile number . . .');
        }
        
       // makePaymentCC();
        console.log('cardNumber.value    : '+ cardNumber.value+' cardExpiry.value  :' +cardExpiry.value+'  cardCvv.value  : '+ cardCvv.value +' cardHolder : '+ cardHolder.value )
        if ((cardNumber.value == null || cardNumber.value == "") || (cardExpiry.value == null || cardExpiry.value == "") || (cardCvv.value == null || cardCvv.value == "") || (cardHolder.value == null || cardHolder.value == "")) {
            alert('Please Enter proper values . . .');
        }
        else {
            makePaymentCC('card');
        }
    }
    
    $scope.payNB = function () {
        console.log('check for null NB')
        var email = document.getElementById("citrusEmail").value;
        //var citrusMerchantTxnId = document.getElementById("citrusMerchantTxnId").value;
        var citrusMobile = document.getElementById("citrusMobile").value;
        var amount = document.getElementById("citrusAmount").value;
        
        if (email == null && email == "" && typeof email == 'undefined') {
            alert('Please Enter Email ID . . .');
        }
       else if (citrusMobile == null && citrusMobile == "" && typeof citrusMobile == 'undefined') {
            alert('Please Enter Mobile number . . .');
        }
       else
       // var postData = { 'email': email, 'mobile': citrusMobile, 'txn_id': $scope.citrusMerchantTxnId, 'amount': amount }
      {  makePaymentCC('netbanking');}
       
    }


})

demoApp.controller('statusController', function ($rootScope, $scope, $routeParams, $location, $http, $window) {
    console.log('in controller1    ')
    
    console.log('  value 1  ' + JSON.stringify($location.search()))
    $scope.trans_id = $location.search().trans_id;
    $scope.amount = $location.search().amount;
    $scope.status = $location.search().status;
    $scope.trans_date = $location.search().trans_date;
    $scope.pay_mode = $location.search().pay_mode;
    
    if ($scope.pay_mode == 'CREDIT_CARD') { 
        $scope.pay_mode= 'CREDIT CARD'
    }
    if ($scope.pay_mode == 'DEBIT_CARD') {
        $scope.pay_mode = 'DEBIT CARD'
    }
    if ($scope.pay_mode == 'NET_BANKING') {
        $scope.pay_mode = 'NET BANKING'
    }

    console.log(' $scope.trans_id     :' + $scope.trans_id)
    
    if ($scope.status == 'SUCCESS') {
        $scope.resStatus = true;
    }
    else {
        $scope.resStatus = false;
    }
})